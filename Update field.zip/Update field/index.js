const url = 'http://jsonplaceholder.typicode.com/users';
const users = document.querySelector('#users');

fetch(url)
.then((resp) => resp.json())
.then(function(data){
    console.log(data);
    let user = data.result;
    console.log(user);
    return user.map(function(info){
        let option = createNode('option');
        option.innerHTML = `${info.name}`;
        append(select, option);
    })
})
.catch(function(error) {
    console.log(JSON.stringify(error));
});